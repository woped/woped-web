module.exports = {
  rootTranslationsPath: 'src/assets/i18n/',
  langs: ['de', 'en'],
  keysManager: {}
};